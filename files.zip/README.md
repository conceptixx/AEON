# AEON Orchestrator v1.0

Minimal, modular Python orchestrator for instruction-based workflows.

## Structure

```
aeon-orchestrator-v1.0/
├── library/
│   ├── orchestrator/
│   │   └── orchestrator.json.py        # Main executable
│   └── python/
│       └── aeon/
│           ├── __init__.py
│           └── actions/
│               ├── __init__.py
│               ├── registry.json        # Action registry
│               └── dummy.py             # Test actions
└── manifest/
    ├── install.entry.json               # Entry instruction
    └── config/
        └── manifest.config.cursed.json  # Test config
```

## Installation

1. Copy the entire `aeon-orchestrator-v1.0` directory to your AEON_ROOT location:
   - macOS: `/usr/local/aeon`
   - Linux: `/opt/aeon`
   
   Or set a custom location:
   ```bash
   export AEON_ROOT=/path/to/your/aeon
   ```

2. Make the orchestrator executable (already done):
   ```bash
   chmod +x library/orchestrator/orchestrator.json.py
   ```

## Usage

### Basic Interactive Mode
```bash
./library/orchestrator/orchestrator.json.py --file:/manifest/install.entry.json
```

### Noninteractive Mode
```bash
./library/orchestrator/orchestrator.json.py --file:/manifest/install.entry.json -n
```

### With Flags
```bash
./library/orchestrator/orchestrator.json.py \
  --file:/manifest/install.entry.json \
  --cli-enable \
  --web-enable \
  -n
```

## CLI Arguments

- `--file:<path>` - Required entry instruction file
- `--config:<path>` - Optional config files (repeatable)
- `-c/-C/--cli-enable/--enable-cli` - Enable CLI mode
- `-w/-W/--web-enable/--enable-web` - Enable web mode
- `-n/-N/--noninteractive/--NONINTERACTIVE` - Run in noninteractive mode

Long flags are case-insensitive.

## Exit Codes

- `0` - Success
- `1` - Runtime/action failure
- `2` - Usage/unknown flag error
- `3` - Validation/schema error
- `4` - Dependency missing (registry/action/module)
- `5` - User abort

## Example Test

From AEON_ROOT, run:

```bash
# Interactive mode (will show warning about missing docker.compose.json)
./library/orchestrator/orchestrator.json.py --file:/manifest/install.entry.json

# Noninteractive mode (uses defaults)
./library/orchestrator/orchestrator.json.py --file:/manifest/install.entry.json -n
```

Expected output:
```
=== AEON Orchestrator Result ===
Mode: interactive
Timestamp: 2025-12-21T...Z

Warnings: 1
  - File will be required eventually: /path/to/aeon/manifest/generated/docker.compose.json

Steps executed: 1
  [OK] menu_selection: ui.curses.menu

================================
```

Result will be written to `${AEON_ROOT}/runtime/last_result.json`.

## Creating New Actions

1. Add your action function to `library/python/aeon/actions/` (or create new module)
2. Register it in `library/python/aeon/actions/registry.json`:
   ```json
   {
     "my.action": {
       "module": "aeon.actions.mymodule",
       "callable": "my_function",
       "deps": []
     }
   }
   ```
3. Use in instruction flows:
   ```json
   {
     "id": "my_step",
     "action": "my.action",
     "args": {"key": "value"}
   }
   ```

## Features

✓ Dynamic action loading via registry
✓ Reference resolution (@step:id, @config:id)
✓ Demand-loading for configs and instructions
✓ Expected files policies (required_now, required_eventually, optional)
✓ Interactive/noninteractive flow support
✓ Comprehensive error handling with proper exit codes
✓ JSON result output with metadata and warnings
✓ Platform-aware AEON_ROOT detection

## Architecture Highlights

- **OrchestratorContext**: Execution context passed to all actions
- **Dynamic imports**: Actions loaded on-demand via Python's import system
- **Recursive reference resolution**: Deep resolution of @step and @config references
- **Hierarchical exceptions**: Each error type has its own exit code
- **Lazy loading**: Referenced instructions stored but not loaded until needed
